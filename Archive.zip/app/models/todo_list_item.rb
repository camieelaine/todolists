class TodoListItem < ActiveRecord::Base
end
